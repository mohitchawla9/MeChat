﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MeChatService.Repository;
using MeChatService.Models;

namespace MeChatService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        private readonly IMeChatServiceRepository<User> _userRepository;

        public UsersController(IMeChatServiceRepository<User> userRepository)
        {
            _userRepository = userRepository;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(User user)
        {
            var registeredUser = await _userRepository.Add(user);
            return Ok(registeredUser);
        }

        //[HttpPost("login")]
        //public async Task<IActionResult> Login(LoginRequest request)
        //{
        //    // Implementation for login
        //}

        //[HttpGet("me")]
        //public async Task<IActionResult> GetCurrentUser()
        //{
        //    // Implementation for getting the current user
        //}

        [HttpGet("{id}")]
        public async Task<IActionResult> GetUser(int id)
        {
            var user = await _userRepository.GetById(id);
            if (user == null)
                return NotFound();

            return Ok(user);
        }

        [HttpGet]
        public async Task<IActionResult> GetUsers()
        {
            var users = await _userRepository.GetAll();
            return Ok(users);
        }

        //[HttpPut("me")]
        //public async Task<IActionResult> UpdateCurrentUser(User user)
        //{
        //    // Implementation for updating the current user
        //}

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var isDeleted = await _userRepository.Delete(id);
            if (!isDeleted)
                return NotFound();

            return NoContent();
        }
    }

}
