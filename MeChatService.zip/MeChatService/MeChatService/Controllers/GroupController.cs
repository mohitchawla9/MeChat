﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MeChatService.Models;
using MeChatService.Repository;

namespace MeChatService.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class GroupsController : ControllerBase
    {
        private readonly IMeChatServiceRepository<Group> _groupRepository;

        public GroupsController(IMeChatServiceRepository<Group> groupRepository)
        {
            _groupRepository = groupRepository;
        }

        [HttpPost]
        public async Task<IActionResult> CreateGroup(Group group)
        {
            var createdGroup = await _groupRepository.Add(group);
            return Ok(createdGroup);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetGroup(int id)
        {
            var group = await _groupRepository.GetById(id);
            if (group == null)
                return NotFound();

            return Ok(group);
        }

        [HttpGet]
        public async Task<IActionResult> GetGroups()
        {
            var groups = await _groupRepository.GetAll();
            return Ok(groups);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateGroup(int id, Group group)
        {
            if (id != group.Id)
                return BadRequest();

            var updatedGroup = await _groupRepository.Update(group);
            return Ok(updatedGroup);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGroup(int id)
        {
            var isDeleted = await _groupRepository.Delete(id);
            if (!isDeleted)
                return NotFound();

            return NoContent();
        }
    }
}
