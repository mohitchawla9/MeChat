﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MeChatService.Models;
using MeChatService.Repository;

namespace MeChatService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GroupMessagesController : ControllerBase
    {
        private readonly IMeChatServiceRepository<GroupMessage> _groupMessageRepository;

        public GroupMessagesController(IMeChatServiceRepository<GroupMessage> groupMessageRepository)
        {
            _groupMessageRepository = groupMessageRepository;
        }

        [HttpPost("groups/{id}/messages")]
        public async Task<IActionResult> CreateGroupMessage(int id, GroupMessage message)
        {
            // Set the group ID for the message
            message.GroupId = id;

            var createdMessage = await _groupMessageRepository.Add(message);
            return Ok(createdMessage);
        }

        [HttpGet("groups/{id}/messages")]
        public async Task<IActionResult> GetGroupMessages(int id)
        {
            var messages = await _groupMessageRepository.GetAll();
            var groupMessages = messages.Where(m => m.GroupId == id);
            return Ok(groupMessages);
        }

        [HttpGet("groups/{groupId}/messages/{messageId}")]
        public async Task<IActionResult> GetGroupMessage(int groupId, int messageId)
        {
            var message = await _groupMessageRepository.GetById(messageId);
            if (message == null || message.GroupId != groupId)
                return NotFound();

            return Ok(message);
        }

        [HttpPut("groups/{groupId}/messages/{messageId}")]
        public async Task<IActionResult> UpdateGroupMessage(int groupId, int messageId, GroupMessage updatedMessage)
        {
            if (messageId != updatedMessage.Id || groupId != updatedMessage.GroupId)
                return BadRequest();

            var existingMessage = await _groupMessageRepository.GetById(messageId);
            if (existingMessage == null || existingMessage.GroupId != groupId)
                return NotFound();

            existingMessage.Content = updatedMessage.Content;

            var updatedGroupMessage = await _groupMessageRepository.Update(existingMessage);
            return Ok(updatedGroupMessage);
        }

        [HttpDelete("groups/{groupId}/messages/{messageId}")]
        public async Task<IActionResult> DeleteGroupMessage(int groupId, int messageId)
        {
            var isDeleted = await _groupMessageRepository.Delete(messageId);
            if (!isDeleted)
                return NotFound();

            return NoContent();
        }
    }

}
